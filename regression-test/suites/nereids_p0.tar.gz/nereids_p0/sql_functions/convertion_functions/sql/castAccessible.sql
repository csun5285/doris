-- database: presto; groups: qe, conversion_functions
SELECT CAST(10 as VARCHAR)
