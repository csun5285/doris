select name from tpch_tiny_nation where name like '%AN'
