SELECT ref_0.`supplycost`
FROM regression_test_nereids_p0_limit.tpch_tiny_partsupp AS ref_0
ORDER BY ref_0.`supplycost`
LIMIT 10;