-- database: presto; groups: no_from
SELECT 1, 1.1, 100*5.1, 'a', 'dummy values', TRUE, FALSE