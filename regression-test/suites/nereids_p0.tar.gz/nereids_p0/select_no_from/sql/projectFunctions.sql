-- database: presto; groups: no_from
SELECT abs(-10.0E0), log2(4), TRUE AND FALSE, TRUE OR FALSE
