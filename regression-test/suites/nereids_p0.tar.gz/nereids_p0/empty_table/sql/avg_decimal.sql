SELECT avg(c3) from empty
